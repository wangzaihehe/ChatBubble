# ChatBubble 材质包

这是ChatBubble插件的配套材质包，提供聊天气泡的视觉效果。

## 安装方法

### 方法1：直接安装
1. 下载 `ChatBubble-ResourcePack.zip` 文件
2. 将ZIP文件放入Minecraft的 `resourcepacks` 文件夹
3. 在游戏中选择材质包并启用

### 方法2：手动安装
1. 解压ZIP文件到Minecraft的 `resourcepacks` 文件夹
2. 在游戏中选择材质包并启用

## 文件夹结构
```
ChatBubble-ResourcePack/
├── pack.mcmeta          # 材质包元数据
├── README.md           # 说明文件
└── assets/
    └── minecraft/
        └── textures/
            └── gui/
                └── chat_bubble.png  # 聊天气泡纹理
```

## 兼容性
- **Minecraft版本**: 1.21+
- **Pack格式**: 18
- **插件要求**: ChatBubble插件

## 功能
- 提供聊天气泡的视觉纹理
- 支持自定义气泡样式
- 与ChatBubble插件完美配合

## 注意事项
- 需要同时安装ChatBubble插件才能看到效果
- 材质包版本需要与插件版本匹配
- 建议在客户端启用材质包以获得最佳效果
